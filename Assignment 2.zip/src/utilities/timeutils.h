#pragma once

double getTimeDeltaSeconds();