#pragma once

#include "mesh.h"

unsigned int generateBuffer(Mesh &mesh);

void addTangentBuffers(unsigned int vaoID, Mesh& mesh);